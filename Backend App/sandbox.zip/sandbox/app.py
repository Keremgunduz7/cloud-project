from flask import Flask, request
app = Flask(__name__)

@app.route('/', methods=['GET'])
def index():

  text = request.form['text']
  empText = ""
  for i in range(len(text)):
      ascVal = ord(text[i])
      char = text[i]
      if char in ('.' , ' ' , ',' , ';' , '!' , '?' , '\n' , '\t'):
          empText += chr(ascVal)
      elif char in ('a' , 'b' , 'c' , "A" , 'B' , 'C'):
          empText += chr(ascVal + 23)
      else:
          empText += chr(ascVal - 3)
  return (empText)

if __name__ == "__main__":
    app.run(debug=True)
  